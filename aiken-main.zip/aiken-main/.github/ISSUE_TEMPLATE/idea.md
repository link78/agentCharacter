---
name: idea
about: Propose an idea or request a feature.

---

### What is your idea? Provide a use case.

### Why is it a good idea?

### What is the current alternative and why is it not good enough?
