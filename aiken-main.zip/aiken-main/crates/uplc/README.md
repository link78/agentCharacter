# Untyped Plutus Core

A crate for working with untyped plutus core. It handles
parsing, conversion between various forms, and flat encoding/decoding.
