The tests here are mostly unit tests to make sure that built-in functions
produce correct results.