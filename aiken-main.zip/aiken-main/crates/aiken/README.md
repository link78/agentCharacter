# CLI

This is the crate that contains the aiken command line application
which bundles together all the other crates in this project.

## Install

`cargo install aiken`
