pub trait ExtraData {
    fn extra_data(&self) -> Option<String>;
}
