# Project

This crate encapsulates the code used to manage Aiken projects. See [crates/cli](../cli) for usage.
