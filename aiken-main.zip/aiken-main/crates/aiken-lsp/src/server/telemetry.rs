use aiken_project::telemetry::EventListener;

pub struct Lsp;

impl EventListener for Lsp {}

impl Lsp {}
